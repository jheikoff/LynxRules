struct Assertion
    seq::Int64
    fact::Fact
end