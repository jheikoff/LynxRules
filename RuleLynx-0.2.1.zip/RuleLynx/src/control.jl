next_seq = 1

function assert(fact::Fact)
    if haskey(current_inference.assertion_index, fact)
        return current_inference.assertion_index[fact]
    end
    assertion = Assertion(next_seq, fact)
    current_inference.working_memory[next_seq] = assertion
    current_inference.assertion_index[fact] = assertion
    global next_seq += 1
    return assertion
end

macro assert(clause)
    # dump(clause)
    fact = Fact(clause.args[1], Tuple(clause.args[2:end]))
    quote
        assert($fact)
    end
end

function retract(assertion::Assertion)::Nothing
    delete!(current_inference.working_memory, assertion.seq)
    delete!(current_inference.assertion_index, assertion.fact)
    nothing
end

function wm()
    for assertion in values(current_inference.working_memory)
        println("$(assertion.seq): $(assertion.fact)")
    end
end