# inference.jl
# Licensed under the MIT License. See LICENSE.md file in the project root for
# full license information.

"""
    Inference

An inference instance represents the state of an inference. Specifically, it
contains ...

# Fields

You should generally use the @inference macro to create a new inference.
"""
mutable struct Inference
	working_memory::SortedDict{Int64, Any}
	assertion_index::Dict{Fact, Any}
    Inference() = new(SortedDict{Int64, Any}(), Dict{Fact, Any}())
end

# The current inference is a global variable designating the currently active
# inference. Unfortunately, there is no way (currently) to associate a type
# with a global variable but we would like to have:
# current_inference::Union{Inference, Nothing} = nothing

"The current active inference"
current_inference = nothing

current_working_memory() = current_inference.working_memory

current_assertion_index() = current_inference.assertion_index

# @inference macro

"""
    @inference begin
	    <body>
	end

Execute the body within a new inference environment. This is the easiest way
to ensure a new, clean inference environment.
"""
macro inference(body)
    quote
		begin
			global current_inference
		    old_inference = current_inference
		    current_inference = Inference()
		    try
		        $(esc(body))
		    catch e
		        showerror(stdout, e, catch_backtrace())
		    finally
		        current_inference = old_inference
			end
		end
	end
end

"""
    @inference <inference> begin
	    <body>
	end

Execute the body within the specified inference environment.
"""
macro inference(inference::Inference, body)
    quote
		begin
			global current_inference
		    old_inference = current_inference
		    current_inference = inference
			try
		    	$(esc(body))
			catch e
		    	showerror(stdout, e, catch_backtrace())
			finally
		    	current_inference = old_inference
			end
		end
	end
end
