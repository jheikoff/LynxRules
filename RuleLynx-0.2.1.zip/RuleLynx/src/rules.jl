struct Rule
    name::Symbol
    preconditions::Vector{Pattern}
    action::Function
end

applyRule(rule::Rule, args::Vector) = rule.action(args...)

mutable struct Ruleset
    name::Symbol
    rules::Vector{Rule}
    Ruleset(name::Symbol) = new(name, Vector{Rule}[])
end

function addRule!(ruleset::Ruleset,
                 name::Symbol,
                 preconditions::Vector{Pattern},
                 action::Function)
    rule = Rule(name, preconditions, action)
    push!(ruleset.rules, rule)
end

function precondition_variables(preconditions)
    variables = Symbol[]
    for pattern in preconditions
        for arg in pattern.arguments
            if isvariable(arg) && arg ∉ variables
                push!(variables, arg)
            end
        end
    end
    variables
end

macro rule(spec, clauses)
    name = QuoteNode(spec.args[1])
    # dump(clauses)
    ndx = findfirst(node -> node === Symbol("=>"), clauses.args)
    # extract patterns
    preconditions = Pattern[]
    for clause in clauses.args[1:ndx - 1]
        if typeof(clause) == Expr
            clause.head === :call || error("expected call got $(clause.head)")
            # push!(preconditions, Pattern(clause.args[1], Tuple((map(eval, clause.args[2:end])))))
            push!(preconditions, Pattern(clause.args[1], Tuple(clause.args[2:end])))
        end
    end
    @show precondition_variables(preconditions)
    body = clauses.args[ndx + 1:end]
    # @show body
    quote
        addRule!($(esc(spec.args[2])),
                 $name,
                 $preconditions,
                 () -> nothing)
    end
end